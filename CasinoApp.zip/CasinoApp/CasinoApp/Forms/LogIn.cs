﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CasinoApp
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Register register = new Register();
            register.Show();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";

        }


        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar))
            {
                e.Handled = false;

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Enter correct username!");

            }

        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                e.Handled = false;

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Password must contain only digits");

            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\gabri\OneDrive\Работен плот\CasinoApp\CasinoApp\bin\Debug\DB.mdf;Integrated Security=True;Asynchronous Processing=True;User Instance=False;Context Connection=False");
            DataTable dt1 = new DataTable();
            string strcmd1 = "";
            SqlDataAdapter cmd1 = new SqlDataAdapter(strcmd1, connect);
            connect.Open();
            strcmd1 = "Select * from Table Where username = '" + txtUsername.Text.Trim() + "' and password = '" + txtPassword.Text.Trim() + "'";


            cmd1 = new SqlDataAdapter(new SqlCommand(strcmd1));
            cmd1.SelectCommand.Connection = connect;

            cmd1.Fill(dt1);
            if ((dt1.Rows.Count > 0))
            {
                Home home = new Home();
                home.Show();
            }
            else
            {
                MessageBox.Show("invalid username or password");
            }
        }
    }
}
