﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CasinoApp
{
    public partial class Deposit : Form
    {
        public static double balance;
        public Deposit()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtBalance.Text != "")
            {
                balance = Convert.ToInt32(txtBalance.Text);
                Home.homeBalance += balance;
                this.Hide();
                Home home = new Home();
                home.Show();
            }else
            {
                MessageBox.Show("Enter your deposit!");
            }
            
        }
    }
}
